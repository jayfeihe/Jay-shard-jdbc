package com.test.mapper;

import com.test.model.City;

public interface CityMapper {
	
	public void createCity(City city);
	
	public City getCityByCityId(Integer cityId);

}
